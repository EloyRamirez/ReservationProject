/********************************************************/
/*** Title: main.cpp
/*** Course: Computational Problem Solving CPET-II
/*** Developer: Marco Smith
/*** Date: 9/25/2020
/********************************************************/


#include "Vehicle.h"
#include "Reservation.h"
#include "menu.h"

using namespace std;


int main() {
	LaunchMenu();
	return 0;
};
