/********************************************************/
/*** Title: Reservation.h										     
/*** Course: Computational Problem Solving CPET-II		
/*** Developer: Marco Smith							    
/*** Date: 9/25/2020						
/********************************************************/

#ifndef RESERVATIONH
#define RESERVATIONH

#include <iostream>
#include <string>
#include <fstream>

#include "Vehicle.h"

using namespace std;


class Reservation {
	private:
		string firstname; // name of who made reservation
		string lastname; // name of who made reservation
		
		string vehiclename; // what type of vehicle reserved
		string vehiclecolor; // coloe of vehicle reserved

		int credits = 0; // number of credits person has
		int seat = 0; //seat in vehicle; identified by cost
		int reservationNumber = 0; //number (0-18) assigned after reservation has been made
		
	public:
		void Create();
		void Create(string userFirstName, string userLastName, string VehicleType, string VehicleColor, int userCredits, int userSeat, int userNum);
		void Modify(string VehicleType, string VehicleColor, int userCredits, int userSeat);
		void Delete();

		int ReturnReservation() const; //return reservation number
		string GetNameKey() const; //return user's name as one string
		string GetVehicleTag() const; //return vehicle as one string
		int GetSeatCost() const; // returns cost of seat
};		

#endif