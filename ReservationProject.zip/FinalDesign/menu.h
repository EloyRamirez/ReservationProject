/********************************************************/
/*** Title: menu.h
/*** Course: Computational Problem Solving CPET-II
/*** Developer: Marco Smith
/*** Date: 9/25/2020
/********************************************************/

#include <iostream>
#include <map>
#include <sstream> 
#include <vector>
#include <ctype.h> 
#include <stdio.h> 
#include <cstdlib>
#include <stdlib.h>
#include <cmath>
#include <iomanip>
#include <ctime>

#include "Vehicle.h"
#include "Reservation.h"

using namespace std;


int GetSeatCost(string& VehicleType, string& SeatType);
bool ValidateVehicle(string& VehicleColor, string& VehicleType);
void DisplayVehicles(vector<Vehicle>& list); /// shows each vehicle and their seating based off cost
void ReservationPrint(vector<Vehicle>& list); /// prints complete list with info of every reservations

void LaunchMenu(); //starts menu program