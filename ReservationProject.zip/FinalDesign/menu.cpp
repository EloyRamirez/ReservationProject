/********************************************************/
/*** Title: menu.cpp
/*** Course: Computational Problem Solving CPET-II
/*** Developer: Marco Smith
/*** Date: 9/25/2020
/********************************************************/


#include "menu.h"

void LaunchMenu() {
	unsigned int i;
	string userFirstName, userLastName;
	int userCredits = -1; // number of credits user has, if -1 then user is a driver

	vector<Reservation> madeReservations;
	vector<string> rawStrings; // raw string data from dat file

	map<string, int> Passengers; // dictionary that stores int indexed by string

	string adminPassword = "abcd"; // password for print all function

//================[READ DAT FILE]================//

	string readLine;
	ifstream datFile("quidditch_team.dat");
	if (datFile.is_open()) {
		while (getline(datFile, readLine)) {
			rawStrings.push_back(readLine); // stores dat file info into vector for later parsing
			cout << "String: " << readLine << " has been saved to rawStrings Vector" << '\n';
		}
		datFile.close();
	}
	else cout << "Unabled to open Dat file";

	cout << '\n' << "Sorting String Data..." << '\n';

	//================[PARSE INTO DICTIONARY]================//

	string namekey;
	for (i = 0; i < rawStrings.size(); i++) {
		stringstream ss(rawStrings.at(i));
		ss >> userFirstName >> userLastName >> userCredits;
		//create key for user data within dictionary
		namekey = userFirstName + " " + userLastName;
		//print for confirmation
		cout << "Name: " << namekey << " , Credits = " << userCredits << '\n';
		Passengers[namekey] = userCredits;
	}

	cout << '\n' << "Data Sorted into dictionary!" << '\n';

	//================[CREATE VEHICLES]================//

	Vehicle purpleTruck;
	Vehicle redCompact;
	Vehicle blueCompact;
	Vehicle yellowCompact;
	Vehicle blueSedan;
	Vehicle greenSedan;

	vector<Vehicle> vehicleList;
	vector<int> vehicleSeats;

	//create purple truck object
	vehicleSeats = { 5 }; // 1 front seat
	purpleTruck.Create("Purple Truck", "Pat Cooper", vehicleSeats, "Purple", "Truck");
	vehicleList.push_back(purpleTruck);

	//create red compact object
	vehicleSeats = { 5, 3, 3 };  // 1 front seat, 2 back seats
	redCompact.Create("Red Compact", "Jane Cox", vehicleSeats, "Red", "Compact");
	vehicleList.push_back(redCompact);

	//create blue compact object
	vehicleSeats = { 5, 3, 3 };  // 1 front seat, 2 back seats
	blueCompact.Create("Blue Compact", "Tim Taylor", vehicleSeats, "Blue", "Compact");
	vehicleList.push_back(blueCompact);

	//create yellow compact object
	vehicleSeats = { 5, 3, 3 };  // 1 front seat, 2 back seats
	yellowCompact.Create("Yellow Compact", "Ben Butler", vehicleSeats, "Yellow", "Compact");
	vehicleList.push_back(yellowCompact);

	//create blue sedan object
	vehicleSeats = { 5, 2, 1, 2 };  // 1 front seat, 2 back seats, 1 middle
	blueSedan.Create("Blue Sedan", "Art Campbell", vehicleSeats, "Blue", "Sedan");
	vehicleList.push_back(blueSedan);

	//create green sedan object
	vehicleSeats = { 5, 2, 1, 2 };  // 1 front seat, 2 back seats, 1 middle
	greenSedan.Create("Green Sedan", "Art Campbell", vehicleSeats, "Green", "Sedan");
	vehicleList.push_back(greenSedan);

	//================[MENU FUNTIONALITY]================//
	char userChoice = '-'; // yes or no input
	char tempChoice;
	char enteredIdNum = '_'; //number entered to find specific reservation object
	bool closeMenu = true; // decides to re-enter menu loop or end program
	bool searchFor_Modify = false; // determines if reservation was found for modify function
	bool identityConfirmed = false;
	bool reservationComplete = false;
	bool validReservation = false;
	string enteredFirstName;
	string enteredLastName;
	string enteredVehicleType = "na";
	string tempVehicleType;
	string enteredSeatType = "na";
	string tempSeatType;
	string enteredVehicleColor = "na";
	string tempVehicleColor;
	string enteredKey;
	string entered_passWord; // entered passWord
	string userAction = "na";
	string printChoice = "na";
	int enteredSeat = -1;
	int foundCredits;
	int reservationNum = 0;
	int char_int;

	while (closeMenu == true) {
		cout << '\n' << '\n' << "-===[LOADING RESERVATION MENU]===-";
		//menu intro
		do {
			cout << '\n' << "DO YOU WISH TO MAKE A RESERVATION? (y/n) ";
			cin >> tempChoice;
			if (isdigit(tempChoice) == false) { //input is not an int so it must be a char
				userChoice = tolower(tempChoice);
			}
		} while (userChoice == '-');

		if (userChoice == 'y') {
			DisplayVehicles(vehicleList);
			//input name
			do {
				cin.ignore();

				cout << '\n' << "PLEASE ENTER THE NAME OF A TEAM MEMBER TO MAKE RESERVATION:";
				cout << '\n' << "First Name: ";
				getline(cin, enteredFirstName);

				cout << '\n' << "Last Name: ";
				getline(cin, enteredLastName);

				enteredKey = enteredFirstName + " " + enteredLastName;

				for (auto it = Passengers.begin(); it != Passengers.end(); ++it) {
					if (it->first == enteredKey) {
						foundCredits = it->second; // get credit amount from dictionary
						cout << '\n' << enteredKey << " Is a valid member name! Credits = " << foundCredits << '\n';
						if (foundCredits == 0) {
							cout << '\n' << "ERROR: " << enteredKey << " has 0 credits and cannot make a reservation!" << '\n';
						}
						else if (foundCredits < 0) {
							cout << '\n' << "ERROR: " << enteredKey << " is a driver and does not need to make a reservation!" << '\n'; // if they enter the name of a driver
						}
						identityConfirmed = true;
						break;
					}
				}
				if (identityConfirmed == false) {
					cout << '\n' << "ERROR: " << enteredKey << " Is NOT a valid member name!" << '\n';
					break;
				}
			} while (identityConfirmed == false);

			if (identityConfirmed == true && foundCredits > 0) {
				userChoice = '-';
				//search by seat category or by vehicle
				do {
					cout << '\n' << "HOW WOULD YOU LIKE TO SEARCH FOR A SEAT?" << '\n' << "a) Search by category" << '\n' << "b) Select specific vehicle and seat" << '\n' << "Choose: ";
					cin >> tempChoice;
					if (isdigit(tempChoice) == false) { //input is not an int so it must be a char
						userChoice = tolower(tempChoice);
					}
				} while (userChoice == '-');

				if (userChoice == 'a') {
					cin.ignore();
					do {
						cout << '\n' << "WHAT TYPE OF SEAT DO YOU WANT? (Front, Back or Middle): ";
						getline(cin, tempSeatType);
						enteredSeatType = tempSeatType;
						cout << '\n' << "CHOSEN SEAT TYPE: " << enteredSeatType;
						cout << '\n' << "FINDING NEXT AVAILIBLE SEAT...";

						for (i = 0; i < vehicleList.size(); i++) {
							enteredSeat = vehicleList.at(i).GetAvailibleSeat(enteredSeatType);
							if (enteredSeat > 0) {
								if (foundCredits < enteredSeat) {
									cout << "\nERROR: seat was found but " << enteredKey << " cannot afford it!";
								}
								else {
									validReservation = true;
									enteredVehicleType = vehicleList.at(i).GetVehicleType();
									enteredVehicleColor = vehicleList.at(i).GetVehicleColor();
									cout << '\n' << "CHOSEN VEHICLE TYPE: " << enteredVehicleColor << " " << enteredVehicleType;
									cout << '\n' << "CHOSEN SEAT TYPE: " << enteredSeatType << " (cost: " << enteredSeat << " credits)";
									///charge player for seat cost!
									for (auto it = Passengers.begin(); it != Passengers.end(); ++it) {
										if (it->first == enteredKey) {
											it->second = it->second - enteredSeat;
											cout << '\n' << enteredKey << " spent " << enteredSeat << " credits";
											cout << '\n' << enteredKey << ", Credits: " << it->second << " credits" << '\n';
											break;
										}
									}
								}
								break;
							}
						}

						if (validReservation == false) {
							if (madeReservations.size() < 18) { // check to make sure there are seats availible to keep user out of inifinite loop
								enteredSeatType = "na"; // value reset to reprompt
							}
							cout << "\nERROR: could not find an availible seat!\n";
						}

					} while (enteredSeatType == "na");
				}
				else if (userChoice == 'b') {
					cin.ignore();
					do {
						cout << '\n' << "WHAT TYPE OF VEHICLE DO YOU WANT? (Truck, Compact, Sedan): ";
						getline(cin, tempVehicleType);

						cout << '\n' << "WHAT COLOR OF VEHICLE DO YOU WANT? " << '\n' << "Truck = Purple" << '\n' << "Compact = Red, Blue, Yellow" << '\n' << "Sedan = Blue, Green" << '\n' << "Choice: ";
						getline(cin, tempVehicleColor);
						enteredVehicleColor = tempVehicleColor;

						cout << '\n' << "WHAT TYPE OF SEAT DO YOU WANT? (Front, Back or Middle): ";
						getline(cin, tempSeatType);
						enteredVehicleType = tempVehicleType;

						if (ValidateVehicle(tempVehicleColor, tempVehicleType)) {
							enteredSeatType = tempSeatType;
							enteredSeat = GetSeatCost(enteredVehicleType, enteredSeatType);

							if (enteredSeat > 0 && enteredSeat > foundCredits) {
								cout << '\n' << "ERROR: " << enteredKey << " has insufficient credits!" << '\n';
								break;
							}
							else if (enteredSeat > 0 && enteredSeat < foundCredits) { /// edit credit value
								for (auto it = Passengers.begin(); it != Passengers.end(); ++it) {
									if (it->first == enteredKey) {
										it->second = it->second - enteredSeat;
										cout << '\n' << enteredKey << " spent " << enteredSeat << " credits";
										cout << '\n' << enteredKey << ", Credits: " << it->second << " credits" << '\n';
										break;
									}
								}
								validReservation = true;
								cout << '\n' << "CHOSEN VEHICLE TYPE: " << enteredVehicleColor << " " << enteredVehicleType;
								cout << '\n' << "CHOSEN SEAT TYPE: " << enteredSeatType << " (cost: " << enteredSeat << " credits)";
							}
							else if (enteredSeat <= 0) { /// could not find an availible seat
								cout << '\n' << "ERROR: desired seat could not be found or is unavailible!" << '\n';
								break;
							}
						}
						else {
							enteredVehicleColor = "na";
							enteredSeatType = "na";
							enteredVehicleType = "na";
							cout << "\n ERROR: INVALID VEHICLE ENTERED! \n";
						}

					} while (enteredVehicleType == "na" && enteredSeatType == "na" && enteredVehicleColor == "na");
				}
				else {
					cout << '\n' << "ERROR: INVALID CHOICE!";
					userChoice = '-';
				}

				//confirm reservation; output passenger list for specific vehicle
				if (validReservation == true) {
					userChoice = '-';
					do {
						cout << '\n' << "DO YOU WISH TO CONFIRM THIS RESERVATION? (y/n)  ";
						cin >> tempChoice;
						if (isdigit(tempChoice) == false) { //input is not an int so it must be a char
							userChoice = tolower(tempChoice);
						}
					} while (userChoice == '-');

					if (userChoice != 'y') { // chose no or an invalid input; re-load menu

						for (auto it = Passengers.begin(); it != Passengers.end(); ++it) {
							if (it->first == enteredKey) {
								it->second = it->second + enteredSeat; // refunds user for reservation edit

								cout << '\n' << enteredKey << " was refunded " << enteredSeat << " credits";
								cout << '\n' << enteredKey << ", Credits: " << it->second << " credits" << '\n';

								foundCredits = it->second; // get credit amount from dictionary
								break;
							}
						}

						cout << '\n' << "YOUR PREVIOUS RESERVATION WAS NOT SAVED!";
					}
					else { //confirmed reservation
						Reservation newReservation;
						reservationNum = madeReservations.size();
						newReservation.Create(enteredFirstName, enteredLastName, enteredVehicleType, enteredVehicleColor, foundCredits, enteredSeat, reservationNum);
						cout << '\n' << "Created Reservation #" << reservationNum << " for " << enteredFirstName << " " << enteredLastName;
						madeReservations.push_back(newReservation); /// saves reservation to vector

						//modified vehicle object that has been reserved
						string vehicleAssignment = enteredVehicleColor + " " + enteredVehicleType;
						enteredKey = enteredFirstName + " " + enteredLastName;
						for (i = 0; i < vehicleList.size(); i++) {
							if (vehicleList.at(i).GetVehicleName() == vehicleAssignment) {
								vehicleList.at(i).ModifySeats(enteredSeat, enteredKey);
								vehicleList.at(i).PrintVehicle();
								break;
							}
						}
					}
				}
			}

		}
		else if (userChoice == 'n') {

			if (madeReservations.size() > 0) {
				cin.ignore();
				//prompt to modify, delete or print reservation; update passenger list for specific vehicle
				do {
					cout << '\n' << "WHAT DO YOU WISH TO DO? (Modify, Delete, Print, Exit)  ";
					getline(cin, userAction);
				} while (userAction == "na");

				///MODIFY FUNCTIONALITY///

				if (userAction == "Modify") {
					cout << '\n' << "ENTER THE ID NUMBER OF THE RESERVATION YOU WISH TO MODIFY: ";
					cin >> enteredIdNum;
					if (isdigit(enteredIdNum)) {
						char_int = ((int)enteredIdNum) - 48;
						cout << '\n' << "SEARCHING FOR RESERVATION #" << enteredIdNum;

						for (i = 0; i < (int)madeReservations.size(); i++) {
							if (char_int == madeReservations.at(i).ReturnReservation()) {
								cout << '\n' << "FOUND RESERVATION #" << enteredIdNum;
								searchFor_Modify = true;

								for (auto it = Passengers.begin(); it != Passengers.end(); ++it) {
									if (it->first == madeReservations.at(i).GetNameKey()) {
										it->second = it->second + madeReservations.at(i).GetSeatCost(); // refunds user for reservation edit

										cout << '\n' << madeReservations.at(i).GetNameKey() << " was refunded " << madeReservations.at(i).GetSeatCost() << " credits";
										cout << '\n' << madeReservations.at(i).GetNameKey() << ", Credits: " << it->second << " credits" << '\n';

										foundCredits = it->second; // get credit amount from dictionary
										break;
									}
								}

								cin.ignore();
								cout << '\n' << "WHAT TYPE OF VEHICLE DO YOU WANT? (Truck, Compact, Sedan): ";
								getline(cin, tempVehicleType);

								cout << '\n' << "WHAT COLOR OF VEHICLE DO YOU WANT? " << '\n' << "Truck = Purple" << '\n' << "Compact = Red, Blue, Yellow" << '\n' << "Sedan = Blue, Green" << '\n' << "Choice: ";
								getline(cin, tempVehicleColor);
								enteredVehicleColor = tempVehicleColor;

								cout << '\n' << "WHAT TYPE OF SEAT DO YOU WANT? (Front, Back or Middle): ";
								getline(cin, tempSeatType);
								enteredSeatType = tempSeatType;
								enteredVehicleType = tempVehicleType;

								enteredSeat = GetSeatCost(enteredVehicleType, enteredSeatType);

								if (enteredSeat > foundCredits) { /// not enough credits to change seat
									cout << '\n' << "RESERVATION #" << enteredIdNum << " COULD NOT BE MODIFIED!";
									// take back refund
									for (auto it = Passengers.begin(); it != Passengers.end(); ++it) {
										if (it->first == madeReservations.at(i).GetNameKey()) {
											it->second = it->second - madeReservations.at(i).GetSeatCost();
											cout << '\n' << madeReservations.at(i).GetNameKey() << " spent " << madeReservations.at(i).GetSeatCost() << " credits";
											cout << '\n' << madeReservations.at(i).GetNameKey() << ", Credits: " << it->second << " credits" << '\n';
											break;
										}
									}
								}
								else {
									for (auto it = Passengers.begin(); it != Passengers.end(); ++it) {
										if (it->first == madeReservations.at(i).GetNameKey()) {
											it->second = it->second - enteredSeat;
											cout << '\n' << madeReservations.at(i).GetNameKey() << " spent " << enteredSeat << " credits";
											cout << '\n' << madeReservations.at(i).GetNameKey() << ", Credits: " << it->second << " credits" << '\n';
											break;
										}
									}

									validReservation = true;
									cout << '\n' << "CHOSEN VEHICLE TYPE: " << enteredVehicleColor << " " << enteredVehicleType;
									cout << '\n' << "CHOSEN SEAT TYPE: " << enteredSeatType << " (cost: " << enteredSeat << " credits)";

									///remove previous seat assignment
									for (unsigned int j = 0; j < vehicleList.size(); j++) {
										if (vehicleList.at(j).GetVehicleName() == madeReservations.at(i).GetVehicleTag()) {
											vehicleList.at(j).OpenSeat(madeReservations.at(i).GetSeatCost(), madeReservations.at(i).GetNameKey());
											break;
										}
									}
									/// make new assignment
									madeReservations.at(i).Modify(enteredVehicleType, enteredVehicleColor, foundCredits, enteredSeat);
									for (unsigned int j = 0; j < vehicleList.size(); j++) {
										if (vehicleList.at(j).GetVehicleName() == madeReservations.at(i).GetVehicleTag()) {
											vehicleList.at(j).ModifySeats(enteredSeat, madeReservations.at(i).GetNameKey());
											vehicleList.at(j).PrintVehicle();
											break;
										}
									}
									cout << '\n' << "RESERVATION #" << enteredIdNum << " HAS BEEN MODIFIED!";
								}
								break; // exit for loop
							}
						}
						if (searchFor_Modify == false) {
							cout << '\n' << "ERROR: could not find the reservation you are looking for!"; // tells user their reservation was not found
						}
					}
					else
						cout << '\n' << "ERROR: could not find the reservation you are looking for!"; // entered a non numeric value
				}

				///DELETE FUNCTIONALITY///

				else if (userAction == "Delete") {
					cout << '\n' << "ENTER THE ID NUMBER OF THE RESERVATION YOU WISH TO DELETE: ";
					cin >> enteredIdNum;
					if (isdigit(enteredIdNum)) {
						char_int = ((int)enteredIdNum) - 48;
						cout << '\n' << "SEARCHING FOR RESERVATION #" << enteredIdNum;

						if ((int)madeReservations.size() >= char_int) {

							for (i = 0; i < (int)madeReservations.size(); i++) {
								if (char_int == madeReservations.at(i).ReturnReservation()) {
									///remove previous seat assignment
									for (unsigned int j = 0; j < vehicleList.size(); j++) {
										if (vehicleList.at(j).GetVehicleName() == madeReservations.at(i).GetVehicleTag()) {
											vehicleList.at(j).OpenSeat(madeReservations.at(i).GetSeatCost(), madeReservations.at(i).GetNameKey());
											cout << "\nVehicle Assignment for " << madeReservations.at(i).GetNameKey() << " has beed removed";
											break;
										}
									}
									madeReservations.at(i).Delete();
									madeReservations.erase(madeReservations.begin() + i);
									cout << '\n' << "DELETED RESERVATION #" << enteredIdNum;
									break;
								}
								else {
									cout << '\n' << "ERROR: could not find the reservation you are looking for!"; // vector was not long enough 
									break;
								}
							}
						}
						else
							cout << '\n' << "ERROR: could not find the reservation you are looking for!"; // vector was not long enough 
					}
					else
						cout << '\n' << "ERROR: could not find the reservation you are looking for!";
				}

				///PRINT FUNCTIONALITY///

				else if (userAction == "Print") {
					cout << '\n' << "WHAT DO YOU WANT TO PRINT? (Single or All) ";
					getline(cin, printChoice);
					if (printChoice == "Single") {
						cout << '\n' << "ENTER THE ID NUMBER OF THE RESERVATION YOU WISH TO PRINT: ";
						cin >> enteredIdNum;

						if (isdigit(enteredIdNum)) {
							char_int = ((int)enteredIdNum) - 48;
							cout << '\n' << "SEARCHING FOR RESERVATION #" << enteredIdNum;
							for (i = 0; i < (int)madeReservations.size(); i++) {
								if (char_int == madeReservations.at(i).ReturnReservation()) {
									cout << '\n' << "FOUND RESERVATION #" << enteredIdNum;
									searchFor_Modify = true;

									for (unsigned int j = 0; j < vehicleList.size(); j++) {
										if (vehicleList.at(j).GetVehicleName() == madeReservations.at(i).GetVehicleTag()) {
											vehicleList.at(j).PrintVehicle();
											break;
										}
									}

									cout << '\n' << "PRINTED RESERVATION #" << enteredIdNum;
									break; // exit for loop
								}
							}
							if (searchFor_Modify == false) {
								cout << '\n' << "ERROR: could not find the reservation you are looking for!"; // tells user their reservation was not found
							}
						}
						else
							cout << '\n' << "ERROR: could not find the reservation you are looking for!"; // entered number but wrong ID
					}

					else if (printChoice == "All") {
						cout << '\n' << "ENTER ADMIN PASSCODE: ";
						getline(cin, entered_passWord);
						if (entered_passWord == adminPassword) {
							ReservationPrint(vehicleList); //print all reservation info
							cout << '\n' << "PRINTING ALL RESERVATIONS";
						}
						else
							cout << '\n' << "ERROR: incorrect passcode! Exiting to main menu!";
					}
					else
						cout << '\n' << "ERROR: invalid print target! Exiting to main menu! ";
				}
				else if (userAction == "Exit") {
					cout << '\n' << "Thank you! Have a nice day!" << '\n';
					break;
				}
				else {
					cout << '\n' << "ERROR: That action could not be performed. Exiting main menu!" << '\n';
					break;
				}
			}
			else {
				cout << '\n' << "NO AVAILIBLE RESERVATIONS TO MODIFY, PRINT OR DELETE. EXITING MAIN MENU!" << '\n';
				break;
			}
		}
		else {
			cout << '\n' << "ERROR: Invalid input, closing program." << '\n';
			break;
		}


		//reset menu variables
		enteredVehicleType = "na";
		enteredSeatType = "na";
		enteredVehicleColor = "na";
		userAction = "na";
		identityConfirmed = false;
		userChoice = '-';
		foundCredits = 0;
		enteredSeat = -1;
		validReservation = false;
		reservationNum = 0;
		enteredIdNum = '_';
		printChoice = "na";
		searchFor_Modify = false;
	}

	cout << '\n' << "Closing Reservation Program!";
	cout << endl;
}

int GetSeatCost(string& VehicleType, string& SeatType) {
	int seatCost = 0;
	if (SeatType == "Front") {
		seatCost = 5;
	}
	else if (SeatType == "Back" && VehicleType != "Truck") {
		if (VehicleType == "Compact") {
			seatCost = 3;
		}
		else if (VehicleType == "Sedan") {
			seatCost = 2;
		}
	}
	else if (SeatType == "Middle" && VehicleType != "Truck") {
		seatCost = 1;
	}
	return seatCost;
};

bool ValidateVehicle(string& VehicleColor, string& VehicleType) {
	vector<string> Vehicles = { "Purple Truck", "Red Compact", "Blue Compact" , "Yellow Compact", "Blue Sedan", "Green Sedan" };
	string vehiclename = VehicleColor + " " + VehicleType;
	unsigned int i;
	bool valid = false;
	for (i = 0; i < (int)Vehicles.size(); i++) {
		if (vehiclename == Vehicles.at(i)) {
			valid = true;
			cout << "\n" << " " << VehicleType << " is a valid Vehicle Name!";
			break;
		}
	}
	return valid;
}

void DisplayVehicles(vector<Vehicle>& list) {
	unsigned int i;

	cout << "\n\nVEHICLE ASSIGNMENTS: ";
	cout << "\n\nKEY:  \n5 = Front Seat \n2 or 3 = Back Seats \n1 = Middle Seat \n0 = Reserved";
	for (i = 0; i < list.size(); i++) {
		cout << "\n\n" << list.at(i).GetVehicleName();
		cout << "\n-------------------------";
		cout << "\n{ ";
		for (unsigned int j = 0; j < list.at(i).GetPassangers().size(); j++) {
			cout << list.at(i).GetPassangers().at(j) << " ";
		}
		cout << " }";
	}
	cout << "\n\n";
}

void ReservationPrint(vector<Vehicle>& list) {
	unsigned int i;

	ofstream reservationFile("all_reservations.txt");

	for (i = 0; i < list.size(); i++) {
		list.at(i).PrintReservation(reservationFile);
	}

	reservationFile.close();
};