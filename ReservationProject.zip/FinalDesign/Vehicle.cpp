/********************************************************/
/*** Title: Vehicle.cpp
/*** Course: Computational Problem Solving CPET-II
/*** Developer: Marco Smith & Eloy Ramirez
/*** Date: 9/25/2020
/********************************************************/

#include "Vehicle.h"
#include <iostream>
#include <string>
using namespace std;

// Function for setting data member defaults 
void Vehicle::Create() {
	vehicleName = "Default Car";
	driver = "Default Driver";
	vehicleColor = "na";
	vehicleType = "na";
	passengers.push_back(0); // push back a 0 zero to fill vector
	originalSeatingCredit.push_back(0); // push back a 0 zero to fill vector
	passengersNames.push_back("Unassigned"); // push back a 0 zero to fill vector
}

// Function for getting user inputs and assinging them to class data members
void Vehicle::Create(string user_VehicleName, string user_Driver, vector<int> user_Passengers, string userColor, string userType) {
	unsigned int i;

	vehicleName = user_VehicleName;
	driver = user_Driver;
	originalSeatingCredit = user_Passengers;
	passengers = user_Passengers;
	vehicleColor = userColor;
	vehicleType = userType;

	/// fill passenger name vector with blank names
	for (i = 0; i < user_Passengers.size(); i++) {
		passengersNames.push_back("Unassigned"); //fills vector to right size with blank names i.e sedan = {"na", "na", "na", "na", "na"}
	}
}

// Functon for modifying seating
void Vehicle::ModifySeats(int targetSeatCredit, string passengerName) {
	unsigned int i;

	for (i = 0; i < passengers.size(); i++) { // For loop that goes through every index in passengers
		if (passengers.at(i) == targetSeatCredit) { // if statement that compares index in passengers and the target seat
			passengers.at(i) = 0; // Sets target seat with a zero to indicate that it's taken
			passengersNames.at(i) = passengerName; // sets corresponding index in passengerName vector
			cout << "\n" << passengersNames.at(i) << " has just reserved a seat in " << vehicleName << " for " << targetSeatCredit << " Credits \n ";
			break; // break so it doesn't target multiple seats
		}
	}
}

void Vehicle::OpenSeat(int previousSeat, string previousOwner) {
	unsigned int i;
	///check to see that seat being identified was actually reserved and the reservation was canceledby the person who made it
	for (i = 0; i < originalSeatingCredit.size(); i++) {
		if (originalSeatingCredit.at(i) == previousSeat && passengers.at(i) == 0 && passengersNames.at(i) == previousOwner) {
			passengers.at(i) = previousSeat;                                  
			passengersNames.at(i) = "Unassigned";
		}
	}
}

void Vehicle::PrintReservation(ofstream& outputFile) {
	/// print out all reservation info line by line
	/// should probably be a function in the vehicle class

	unsigned int i;

	if (outputFile.is_open()) {
		outputFile << "\n\nVehicle: " << vehicleName;
		outputFile << "\nDriver: " << driver;
		outputFile << "\nPassengers: ";
		for (i = 0; i < passengersNames.size(); i++) {
			outputFile << "\n" << passengersNames.at(i);
		}
	}

}

void Vehicle::PrintVehicle() {
	unsigned int i;
	ofstream myfile;
	string vehicleTag = vehicleColor + " " + vehicleType;
	/// Selecting Output File
	if (vehicleTag == "Purple Truck") {
		myfile.open("Purple_Pickup.txt");
	}
	else if (vehicleTag == "Red Compact") {
		myfile.open("Red_Comp.txt");
	}
	else if (vehicleTag == "Blue Compact") {
		myfile.open("Blue_Comp.txt");
	}
	else if (vehicleTag == "Yellow Compact") {
		myfile.open("Yellow_Comp.txt");
	}
	else if (vehicleTag == "Blue Sedan") {
		myfile.open("Blue_Sedan.txt");
	}
	else if (vehicleTag == "Green Sedan") {
		myfile.open("Green_Sedan.txt");
	}

	///output to console
	cout << "\n\nVehicle: " << vehicleName;
	cout << "\nDriver: " << driver;
	cout << "\nPASSENGER LIST: ";
	for (i = 0; i < passengersNames.size(); i++) {
		cout << "\n" << passengersNames.at(i);
	}

	/// Printing to Output File
	if (myfile.is_open()) {
		myfile << "Driver: " << driver;
		myfile << "\nPASSENGER LIST: ";
		for (i = 0; i < passengersNames.size(); i++) {
			myfile << "\n" << passengersNames.at(i);
		}
		myfile.close();
	}
}

// returns vehicle name
string Vehicle::GetVehicleName() const {
	return vehicleName;
}

// returns vehicle color
string Vehicle::GetVehicleColor() const {
	return vehicleColor;
}

// returns vehicle type
string Vehicle::GetVehicleType() const {
	return vehicleType;
}

// returns driver name
string Vehicle::GetDriverName() const {
	return driver;
}

// returns seating
vector<int> Vehicle::GetPassangers() const {
	return passengers;
}

// returns status of selected seat
bool Vehicle::CheckSeat(int seatCost) const {
	return false;
}

// returns first availible seat
int Vehicle::GetAvailibleSeat(string seatType) const {
	unsigned int i;
	int lookFor = 0;
	int foundseat = 0;

	if (seatType == "Front") {
		lookFor = 5;
	}
	else if (seatType == "Back") {
		if (vehicleType == "Compact") {
			lookFor = 3;
		}
		else if (vehicleType == "Sedan") {
			lookFor = 2;
		}
	}
	else if (seatType == "Middle") {
		lookFor = 1;
	}

	for (i = 0; i < passengers.size(); i++) {
		if (passengers.at(i) == lookFor) {
			foundseat = lookFor;
			break;
		}
	}

	return foundseat;
}