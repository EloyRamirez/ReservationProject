/********************************************************/
/*** Title: Vehicle.h
/*** Course: Computational Problem Solving CPET-II
/*** Developer: Marco Smith & Eloy Ramirez
/*** Date: 9/25/2020
/********************************************************/

#ifndef VEHICLEH
#define VEHICLEH

#include <string>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

class Vehicle {
protected:
	string vehicleName; // identifier for specific vehicle w/ color  i.e ("Green Sedan")
	string vehicleColor; // vehicle's Color
	string vehicleType; // vehicle's Type
	string driver; // name of driver for vehicle
	vector<int> passengers; //seating
	vector<string> passengersNames; //names of passengers
	vector<int> originalSeatingCredit; // Seating vector just for referencing seat credits (DOES NOT CHANGE)

public:
	void Create(); // Default constructors
	void Create(string user_VehicleName, string user_Driver, vector<int> user_Passengers, string userColor, string userType); // Sets data members from user inputs
	void ModifySeats(int targetSeatCredit, string passengerName); // Modifies seating
	void OpenSeat(int previousSeat, string previousOwner); //reverts seat to open state
	void PrintReservation(ofstream& outputFile); //prints vehicle description, driver name and list of passengers with seat locations in all_reservations.txt
	void PrintVehicle(); // prints passenger list to output files
	
	string GetVehicleName()const; // returns vehicle name
	string GetVehicleColor()const; // returns vehicle color
	string GetVehicleType()const; // returns vehicle type
	string GetDriverName()const; // returns driver name
	vector<int> GetPassangers() const; // returns seating
	bool CheckSeat(int seatCost) const; // returns current status of sea
	int GetAvailibleSeat(string seatType) const;
};

#endif
