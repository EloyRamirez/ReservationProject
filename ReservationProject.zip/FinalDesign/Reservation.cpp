/********************************************************/
/*** Title: Reservation.cpp
/*** Course: Computational Problem Solving CPET-II
/*** Developer: Marco Smith
/*** Date: 9/25/2020
/********************************************************/

#include "Reservation.h"

void Reservation::Create() {
	firstname = "John";
	lastname = "Doe";
	credits = 9999;
	seat = 0;
	reservationNumber = 99;
	vehiclename = "na";
	vehiclecolor = "na";
}

void Reservation::Create(string userFirstName, string userLastName, string VehicleType, string VehicleColor, int userCredits, int userSeat, int userNum) {
	firstname = userFirstName;
	lastname = userLastName;
	credits = userCredits;
	seat = userSeat;
	reservationNumber = userNum;
	vehiclename = VehicleType;
	vehiclecolor = VehicleColor;
}

void Reservation::Modify(string VehicleType, string VehicleColor, int userCredits, int userSeat) {
	//needs to find what vehicle they were assigned
	//find what seat they picked; return used credits
	//reprompt for vehicle type

	vehiclename = VehicleType;
	vehiclecolor = VehicleColor;
	credits = userCredits;
	seat = userSeat;
}

void Reservation::Delete() {
	firstname = "na";
	lastname = "na";
	credits = 9999;
	seat = 0;
	reservationNumber = 99;
	vehiclename = "na";
	vehiclecolor = "na";
}

int Reservation::ReturnReservation() const {
	return reservationNumber;
}

string Reservation::GetNameKey() const {
	string temp = firstname + " " + lastname;
	return temp;
}

string Reservation::GetVehicleTag() const {
	string temp = vehiclecolor + " " + vehiclename;
	return temp;
}

int Reservation::GetSeatCost() const {
	return seat;
}
